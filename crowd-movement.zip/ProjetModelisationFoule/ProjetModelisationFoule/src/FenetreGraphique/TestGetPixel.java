/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package FenetreGraphique;

import java.awt.Color;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
import coordonnee.Coordonnee;
import agent.Agent;
import foule.Foule;
import java.util.Random;
import simulation.Simulation;

/**
 *
 * @author guillaume.laurent
 */
public class TestGetPixel {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        Coordonnee sortie = new Coordonnee(250,125);
        Coordonnee pos=new Coordonnee(400,300);
        Agent A = new Agent(5,0.5,pos,sortie,Color.blue);
        Random r = Simulation.generateur;
        
        Foule f=new Foule(sortie);
        FenetreGraphique fenetre = new FenetreGraphique("Simu foule", 800, 600);

        fenetre.effacer(new Color(252, 252, 252));
        sortie.dessiner(fenetre, Color.black);
        
        for(int i=0; i<f.getListeFoule().size(); i++){
            
            double x = f.getListeFoule().get(i).getPosition().getX();
            double y = f.getListeFoule().get(i).getPosition().getY();
            
            Coordonnee point = new Coordonnee(x,y);
            point.dessiner(fenetre, Color.blue);
            fenetre.actualiser();
            
        }

        
        

//        for (int y = 0; y < image.getHeight(); y++) {
//            for (int x = 0; x < image.getWidth(); x++) {
//                System.out.print(image.getRGB(x, y) + ", ");
//                
//            }
//            System.out.println("");
//        }
                
        
    }

}
