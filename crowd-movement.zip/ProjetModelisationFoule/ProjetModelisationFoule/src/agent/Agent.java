/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package agent;
import coordonnee.Coordonnee;
import java.awt.Color;
import java.util.Objects;

/**
 *
 * @author fdamblev
 */
public class Agent {
    
    private double rayon;
    private double vitesse;
    private Coordonnee position;
    private Coordonnee objectif;
    private Color couleur;
    private Coordonnee cap;
    
    public Agent(double rayon, double vitesse, Coordonnee position, Coordonnee objectif, Color couleur){
        this.rayon=rayon;
        this.vitesse=vitesse;
        this.position=position;
        this.objectif=objectif;
        this.couleur=couleur;
        this.cap = this.CalculDeCap();
    }

    public double getRayon() {
        return rayon;
    }

    public double getVitesse() {
        return vitesse;
    }

    public Color getCouleur() {
        return couleur;
    }

    public Coordonnee getObjectif() {
        return objectif;
    }
    
    public Coordonnee getPosition(){
        return position;
    }

    public void setRayon(double rayon) {
        this.rayon = rayon;
    }

    public void setVitesse(double vitesse) {
        this.vitesse = vitesse;
    }

    public void setCouleur(Color couleur) {
        this.couleur = couleur;
    }
    
    public Coordonnee CalculDeCap(){
        double capX = (this.objectif.getX()-this.position.getX())/this.objectif.dist(this.position);
        double capY = (this.objectif.getY()-this.position.getY())/this.objectif.dist(this.position);
        Coordonnee c=new Coordonnee(capX,capY);
        return c;
    }

    @Override
    public String toString() {
        return "Agent{" + "rayon=" + rayon + ", vitesse=" + vitesse + ", position=" + position + ", objectif=" + objectif + ", couleur=" + couleur + '}';
    }

    public void deplacer(){
        this.position.setX(this.position.getX()+ this.CalculDeCap().getX()*this.getVitesse());
        this.position.setY(this.position.getY()+ this.CalculDeCap().getY()*this.getVitesse());
    }

    public void setPosition(Coordonnee position) {
        this.position = position;
    }

    public void setCap(Coordonnee cap) {
        this.cap = cap;
    }
    

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Agent other = (Agent) obj;
        return Objects.equals(this.position, other.position);
    }
    
}
