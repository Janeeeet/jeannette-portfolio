/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package foule;
import coordonnee.Coordonnee;
import agent.Agent;
import java.util.ArrayList;
import java.awt.Color;
import java.util.Objects;
import java.util.Random;
import simulation.Simulation;

/**
 *
 * @author fdamblev
 */
public class Foule {
    
    private ArrayList<Agent> listeFoule;
    private Coordonnee sortie;
    
    public Foule(Coordonnee sortie, int n){
        this.sortie=sortie;
        this.listeFoule = new ArrayList<>();
        Random r = Simulation.generateur;
        for(int i=0; i<n; i++){
            double x=r.nextDouble(Simulation.X_MIN, Simulation.X_MAX);
            double y=r.nextDouble(Simulation.Y_MIN, Simulation.Y_MAX);
            Coordonnee position = new Coordonnee(x,y);
            double vitesse = r.nextDouble(Simulation.VITESSE_MIN, Simulation.VITESSE_MAX);
            this.listeFoule.add(new Agent(5, vitesse, position, sortie, Color.blue));
        }
    }

    @Override
    public String toString() {
        return "Foule{" + "listeFoule=" + listeFoule + ", sortie=" + sortie + '}';
    }

    public Coordonnee getSortie() {
        return sortie;
    }

    public void setSortie(Coordonnee sortie) {
        this.sortie = sortie;
    }
    public void supAgent(int i){
        if(this.listeFoule.get(i).getPosition().dist(sortie)<10){
            this.listeFoule.remove(i);
        }
        
    }

    public ArrayList<Agent> getListeFoule() {
        return listeFoule;
    }
    
    public void Collision(){
        for(int i=0;i<this.listeFoule.size();i++){
            for(int j=0;j<this.listeFoule.size();j++){
                if(!this.listeFoule.get(i).equals(this.listeFoule.get(j))){
                   if(this.listeFoule.get(i).getRayon()+this.listeFoule.get(j).getRayon()>this.listeFoule.get(i).getPosition().dist(this.getListeFoule().get(j).getPosition())){
                        this.listeFoule.get(i).setVitesse(0); 
                    }
                }                    
            }
        }
    }
    public void Debloque(){
        Random r = Simulation.generateur;
        for(int i=0;i<this.listeFoule.size();i++){
            for(int j=0;j<this.listeFoule.size();j++){
                if(!this.listeFoule.get(i).equals(this.listeFoule.get(j))){
                   if((this.listeFoule.get(i).getRayon()+this.listeFoule.get(j).getRayon())*3>this.listeFoule.get(i).getPosition().dist(this.getListeFoule().get(j).getPosition())){
                        this.listeFoule.get(i).setCap(this.listeFoule.get(i).CalculDeCap());
                        this.listeFoule.get(i).setVitesse(r.nextDouble(Simulation.VITESSE_MIN, Simulation.VITESSE_MAX));
                    }
                }
            }                
        }
    }
//    public void dessinerAgent(){
//        while(!this.listeFoule.getListeFoule().isEmpty()) {
//            fenetre.effacer();
//            
//            for(int i=0;i<n;i++){                
//                this.listeFoule.getListeFoule().get(i).getPosition().dessiner(fenetre, Color.blue);
//                foule.getListeFoule().get(i).deplacer();
//                
//            }
//            fenetre.actualiser(0.04);
//    }

}
