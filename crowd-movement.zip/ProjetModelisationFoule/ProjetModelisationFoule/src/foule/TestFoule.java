/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package foule;
import FenetreGraphique.FenetreGraphique;
import coordonnee.Coordonnee;
import agent.Agent;
import java.awt.Color;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
/**
 *
 * @author fdamblev
 */
public class TestFoule {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int n=50;
        Coordonnee sortie=new Coordonnee(400,590);
        
        Foule foule =new Foule(sortie, n);
        
        FenetreGraphique fenetre = new FenetreGraphique("Simu foule", 800, 600);
        
        
        boolean listVide=false;
        while(listVide==false) {
            fenetre.effacer();
            sortie.dessiner(fenetre, Color.red, 30);
            for(int i=0;i<foule.getListeFoule().size();i++){
                
                foule.getListeFoule().get(i).getPosition().dessiner(fenetre, Color.blue, 10);
                foule.getListeFoule().get(i).deplacer();
                foule.supAgent(i);
                
            }
            foule.Collision();
            foule.Debloque();
            fenetre.actualiser(0.04);
            if(foule.getListeFoule().isEmpty()){
                listVide=true;
            }
        
        }
        
    }
    
}
