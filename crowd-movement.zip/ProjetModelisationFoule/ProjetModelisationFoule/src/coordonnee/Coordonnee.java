/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package coordonnee;
import FenetreGraphique.FenetreGraphique;
import java.awt.Color;

/**
 *
 * @author fdamblev
 */
public class Coordonnee {
    
    private double x;
    private double y;
    
    public Coordonnee(double x, double y){
        this.x=x;
        this.y=y;
}
    public Coordonnee(){
        this.x=0;
        this.y=0;
    }
    public double getX(){
        return this.x;
    }
    public double getY(){
        return this.y;
    }
    public void setY(double Y){
        this.y=Y;
    }
    public void setX(double X){
        this.x=X;
    }
    public double dist(Coordonnee point){
        return Math.sqrt((this.x-point.getX())*(this.x-point.getX())+(this.y-point.getY())*(this.y-point.getY()));
    }

    @Override
    public String toString() {
        return "Coordonnee{" + "x=" + x + ", y=" + y + '}';
    }
    public int compareTo(Object obj){
        Coordonnee c = (Coordonnee) obj;
        if(this.getX()<c.getX() && this.getY()<c.getY()){
            return -1;
        }
        if(this.getX()>c.getX() && this.getY()>c.getY()){
            return 1;
        }
        return 0;
    }
    public void dessiner(FenetreGraphique f, Color c, int n){
        f.getGraphics2D().setColor(c);
        f.getGraphics2D().fillOval((int)this.getX(),(int)this.getY(), n, n);
    }
}
